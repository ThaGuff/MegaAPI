# Revenue Intelligence Suite

This package includes all 3 deliverables requested:

1. **Functional dashboard:** `index.html`
2. **Client-ready printable PDF report:** Report tab inside `index.html`
3. **Full implementation plan:** `IMPLEMENTATION_PLAN.md`

## Quick start

### Option 1 — easiest
Open `index.html` in your browser.

### Option 2 — local server
If your browser blocks local JSON loading, run:

```bash
cd revenue-intelligence-suite
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## Features
- filterable dashboard
- sample data included
- import your own JSON file
- export filtered CSV
- export filtered JSON
- printable PDF report
- saved notes and report title in browser localStorage

## Files
- `index.html` — main app
- `assets/styles.css` — styles
- `assets/app.js` — app logic
- `data/sample-data.json` — starter data
- `IMPLEMENTATION_PLAN.md` — delivery/build plan

## To customize
1. Replace `data/sample-data.json` with your client data.
2. Or use the "Load custom JSON" button.
3. Update branding/colors in `assets/styles.css`.
4. Update pricing and copy inside `index.html`.
