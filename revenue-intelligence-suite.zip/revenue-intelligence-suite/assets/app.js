const state = {
  data: null,
  filters: { client: 'All', industry: 'All', region: 'All', source: 'All', lever: 'All', priority: 'All' },
  notes: localStorage.getItem('ri_notes') || '',
  reportTitle: localStorage.getItem('ri_report_title') || 'Monthly Revenue Intelligence Report'
};

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));
const money = (n) => new Intl.NumberFormat('en-US', { style:'currency', currency:'USD', maximumFractionDigits:0 }).format(n || 0);
const scoreClass = (n) => n >= 85 ? 'high' : n >= 75 ? 'med' : 'low';
const severityClass = (s) => s === 'High' ? 'high' : s === 'Medium' ? 'med' : 'low';
const uniq = (arr) => ['All', ...new Set(arr.filter(Boolean))];
const csvEscape = (v) => `"${String(v ?? '').replaceAll('"', '""')}"`;

function byFilters(row) {
  const f = state.filters;
  return (f.client === 'All' || row.client === f.client) &&
    (f.industry === 'All' || row.industry === f.industry) &&
    (f.region === 'All' || row.region === f.region) &&
    (f.source === 'All' || row.source === f.source) &&
    (f.lever === 'All' || row.lever === f.lever) &&
    (f.priority === 'All' || row.priority === f.priority || !row.priority && f.priority === 'All');
}

function allRows() {
  const d = state.data || {};
  return [...(d.opportunities||[]), ...(d.leads||[]), ...(d.pricing||[]), ...(d.reviews||[]), ...(d.seo||[]), ...(d.creative||[])];
}

function fillSelect(selectId, values) {
  const el = $(selectId);
  el.innerHTML = values.map(v => `<option value="${v}">${v}</option>`).join('');
  el.value = state.filters[el.dataset.filter] || 'All';
}

function initFilters() {
  const rows = allRows();
  fillSelect('#clientFilter', uniq(rows.map(r => r.client).sort()));
  fillSelect('#industryFilter', uniq(rows.map(r => r.industry).sort()));
  fillSelect('#regionFilter', uniq(rows.map(r => r.region).sort()));
  fillSelect('#sourceFilter', uniq(rows.map(r => r.source).sort()));
  fillSelect('#leverFilter', uniq(rows.map(r => r.lever).sort()));
  fillSelect('#priorityFilter', uniq((state.data.opportunities||[]).map(r => r.priority).sort()));
}

function renderKpis(filtered) {
  const totalOpps = filtered.opportunities.length;
  const pipeline = filtered.opportunities.reduce((a, b) => a + (b.impact || 0), 0);
  const savings = filtered.opportunities.reduce((a, b) => a + (b.savings || 0), 0);
  const score = totalOpps ? Math.round(filtered.opportunities.reduce((a, b) => a + b.score, 0) / totalOpps) : 0;
  const sentiment = totalOpps ? (filtered.opportunities.reduce((a,b)=>a+(b.sentimentGap||0),0) / totalOpps).toFixed(1) : '0.0';
  const price = totalOpps ? Math.round(filtered.opportunities.reduce((a,b)=>a+(b.priceDelta||0),0) / totalOpps) : 0;
  $('#kpiOpps').textContent = totalOpps;
  $('#kpiPipeline').textContent = money(pipeline);
  $('#kpiSavings').textContent = money(savings);
  $('#kpiScore').textContent = score;
  $('#kpiSentiment').textContent = sentiment;
  $('#kpiPrice').textContent = `${price > 0 ? '+' : ''}${price}%`;
  $('#kpiScoreHint').textContent = totalOpps ? `${filtered.opportunities.filter(r=>r.score>=85).length} high-priority items` : 'No matching opportunities';
  $('#kpiPriceHint').textContent = price >= 0 ? 'Priced above competitor median' : 'Priced below competitor median';
  $('#kpiPriceHint').className = price >= 0 ? 'up small' : 'down small';
}

function renderTable(selector, rows, htmlBuilder, emptyCols=4) {
  const body = $(selector);
  body.innerHTML = rows.length ? rows.map(htmlBuilder).join('') : `<tr><td colspan="${emptyCols}" class="muted">No rows match current filters.</td></tr>`;
}

function renderBars(selector, rows, valueKey='value', labelKey='label', formatter=(v)=>v) {
  const wrap = $(selector);
  if (!rows.length) { wrap.innerHTML = '<div class="muted">No data.</div>'; return; }
  const max = Math.max(1, ...rows.map(r => r[valueKey]));
  wrap.innerHTML = rows.map(r => `
    <div class="bar-row">
      <div>${r[labelKey]}</div>
      <div class="bar-track"><div class="bar-fill" style="width:${(r[valueKey]/max)*100}%"></div></div>
      <div>${formatter(r[valueKey])}</div>
    </div>
  `).join('');
}

function topInsights(filtered) {
  const opps = [...filtered.opportunities].sort((a,b)=> (b.impact+b.savings) - (a.impact+a.savings));
  const reviews = [...filtered.reviews].sort((a,b)=>b.mentions-a.mentions);
  const leads = [...filtered.leads].sort((a,b)=>b.fitScore-a.fitScore);
  const insights = [];
  if (opps[0]) insights.push(`Highest-value action: ${opps[0].title} (${money((opps[0].impact||0)+(opps[0].savings||0))}).`);
  if (reviews[0]) insights.push(`Biggest customer pain point: ${reviews[0].theme} (${reviews[0].mentions} mentions).`);
  if (leads[0]) insights.push(`Best expansion pocket: ${leads[0].market} with fit score ${leads[0].fitScore}.`);
  if (!insights.length) insights.push('No insights available for current filters.');
  $('#topInsights').innerHTML = insights.map(t => `<div class="list-item">${t}</div>`).join('');
}

function generateRecommendations(filtered) {
  const recs = [];
  const highOpps = [...filtered.opportunities].sort((a,b)=>b.score-a.score).slice(0,3);
  highOpps.forEach((o, i) => recs.push({ title: `Recommendation ${i+1}`, body: `${o.title} — ${o.detail} Owner: ${o.owner}. ETA: ${o.etaDays} days.` }));
  const topReview = [...filtered.reviews].sort((a,b)=>b.mentions-a.mentions)[0];
  if (topReview) recs.push({ title: 'Customer Experience Fix', body: `${topReview.theme} is the strongest review pain point. Recommended action: ${topReview.action}.` });
  const topSeo = filtered.seo[0];
  if (topSeo) recs.push({ title: 'Demand Capture', body: `Build content around "${topSeo.cluster}" with ${topSeo.intent.toLowerCase()} intent. Priority: ${topSeo.priority}.` });
  $('#recommendations').innerHTML = recs.length ? recs.map(r => `<div class="list-item"><strong>${r.title}:</strong> ${r.body}</div>`).join('') : '<div class="list-item">No recommendations yet.</div>';
}

function getFiltered() {
  const d = state.data;
  return {
    opportunities: (d.opportunities||[]).filter(byFilters),
    leads: (d.leads||[]).filter(byFilters),
    pricing: (d.pricing||[]).filter(byFilters),
    reviews: (d.reviews||[]).filter(byFilters),
    seo: (d.seo||[]).filter(byFilters),
    creative: (d.creative||[]).filter(byFilters)
  };
}

function render() {
  const filtered = getFiltered();
  renderKpis(filtered);
  renderTable('#opportunityRows', [...filtered.opportunities].sort((a,b)=>b.score-a.score), r => `
    <tr>
      <td>${r.client}</td>
      <td><strong>${r.title}</strong><div class="small muted">${r.detail}</div></td>
      <td><span class="tag">${r.source}</span></td>
      <td>${money((r.impact||0)+(r.savings||0))}</td>
      <td>${r.etaDays}d</td>
      <td><span class="score ${scoreClass(r.score)}">${r.score}</span></td>
    </tr>`, 6);

  const leverMap = {};
  filtered.opportunities.forEach(r => leverMap[r.lever] = (leverMap[r.lever] || 0) + (r.impact || 0) + (r.savings || 0));
  renderBars('#leverBars', Object.entries(leverMap).map(([label, value]) => ({label, value})).sort((a,b)=>b.value-a.value), 'value', 'label', money);

  renderTable('#leadRows', filtered.leads, r => `
    <tr><td>${r.market}</td><td>${r.leadPool}</td><td>${r.validContactsPct}%</td><td>${r.gap}</td><td><span class="score ${scoreClass(r.fitScore)}">${r.fitScore}</span></td></tr>`, 5);

  renderBars('#pricingBars', filtered.pricing.map(r => ({label:r.label, value:r.pct})), 'value', 'label', v => `${v}%`);

  renderTable('#reviewRows', filtered.reviews, r => `
    <tr><td>${r.theme}</td><td>${r.mentions}</td><td><span class="score ${severityClass(r.severity)}">${r.severity}</span></td><td>${r.action}</td></tr>`, 4);

  renderTable('#seoRows', filtered.seo, r => `
    <tr><td>${r.cluster}</td><td>${r.intent}</td><td>${r.difficulty}</td><td>${r.priority}</td></tr>`, 4);

  renderTable('#creativeRows', filtered.creative, r => `
    <tr><td>${r.competitor}</td><td>${r.pattern}</td><td>${r.signal}</td><td>${r.test}</td></tr>`, 4);

  topInsights(filtered);
  generateRecommendations(filtered);
  renderReport(filtered);
}

function renderReport(filtered) {
  $('#reportTitle').textContent = state.reportTitle;
  $('#reportDate').textContent = new Date().toLocaleDateString();
  const clients = state.filters.client === 'All' ? 'All clients' : state.filters.client;
  $('#reportScope').textContent = `${clients} • ${state.filters.industry} • ${state.filters.region}`;
  $('#reportSummary').textContent = `Filtered report includes ${filtered.opportunities.length} opportunities, ${filtered.leads.length} lead segments, ${filtered.reviews.length} review themes, and ${filtered.creative.length} creative intelligence rows.`;
  $('#reportKpis').innerHTML = `
    <div class="report-card"><div class="small muted">Qualified opportunities</div><div style="font-size:28px;font-weight:800">${filtered.opportunities.length}</div></div>
    <div class="report-card"><div class="small muted">Estimated pipeline</div><div style="font-size:28px;font-weight:800">${money(filtered.opportunities.reduce((a,b)=>a+(b.impact||0),0))}</div></div>
    <div class="report-card"><div class="small muted">Potential savings</div><div style="font-size:28px;font-weight:800">${money(filtered.opportunities.reduce((a,b)=>a+(b.savings||0),0))}</div></div>
  `;
  const topOpps = [...filtered.opportunities].sort((a,b)=>b.score-a.score).slice(0,5);
  $('#reportOppRows').innerHTML = topOpps.length ? topOpps.map(o => `<tr><td>${o.title}</td><td>${o.source}</td><td>${money((o.impact||0)+(o.savings||0))}</td><td>${o.score}</td></tr>`).join('') : '<tr><td colspan="4">No rows</td></tr>';
  const recItems = $$('#recommendations .list-item').map(el => `<li>${el.textContent}</li>`).join('');
  $('#reportRecommendations').innerHTML = recItems || '<li>No recommendations.</li>';
  $('#reportNotes').textContent = state.notes || 'No analyst notes entered.';
}

function bindEvents() {
  $$('.filter').forEach(el => el.addEventListener('change', (e) => {
    state.filters[e.target.dataset.filter] = e.target.value;
    render();
  }));

  $('#resetFilters').addEventListener('click', () => {
    state.filters = { client:'All', industry:'All', region:'All', source:'All', lever:'All', priority:'All' };
    $$('.filter').forEach(el => el.value = 'All');
    render();
  });

  $('#notes').value = state.notes;
  $('#notes').addEventListener('input', e => {
    state.notes = e.target.value;
    localStorage.setItem('ri_notes', state.notes);
    renderReport(getFiltered());
  });

  $('#reportTitleInput').value = state.reportTitle;
  $('#reportTitleInput').addEventListener('input', e => {
    state.reportTitle = e.target.value;
    localStorage.setItem('ri_report_title', state.reportTitle);
    renderReport(getFiltered());
  });

  $('#exportCsv').addEventListener('click', () => {
    const rows = getFiltered().opportunities;
    const header = ['client','industry','region','source','lever','title','impact','savings','score','priority','status'];
    const csv = [header.join(',')].concat(rows.map(r => header.map(h => csvEscape(r[h])).join(','))).join('\n');
    const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'filtered-opportunities.csv';
    a.click();
  });

  $('#exportJson').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(getFiltered(), null, 2)], {type:'application/json'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'filtered-report-data.json';
    a.click();
  });

  $('#printDashboard').addEventListener('click', () => window.print());
  $('#printReport').addEventListener('click', () => {
    document.body.classList.add('print-report');
    window.print();
  });

  $('#sampleLoader').addEventListener('click', loadSampleData);
  $('#fileInput').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const text = await file.text();
    try {
      state.data = JSON.parse(text);
      initFilters();
      render();
      alert('Custom JSON loaded successfully.');
    } catch(err) {
      alert('Invalid JSON file. Please use the sample schema.');
      console.error(err);
    }
  });

  $$('.nav a').forEach(a => a.addEventListener('click', e => {
    e.preventDefault();
    const tab = a.dataset.tab;
    $$('.tab').forEach(t => t.classList.add('hidden'));
    $(`#${tab}`).classList.remove('hidden');
    $$('.nav a').forEach(x => x.classList.remove('active'));
    a.classList.add('active');
  }));
}

async function loadSampleData() {
  const res = await fetch('./data/sample-data.json');
  state.data = await res.json();
  initFilters();
  render();
}

async function init() {
  bindEvents();
  await loadSampleData();
}

window.addEventListener('DOMContentLoaded', init);
